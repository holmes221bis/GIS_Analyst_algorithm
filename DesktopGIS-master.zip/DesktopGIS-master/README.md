# GIS应用系统
### 该系统是基于ArcEngine 10.2 和C#.NET开发的GIS桌面应用程序,主要适用于全国大学生GIS应用技能大赛

**参考文献：**
1. 牟乃夏等,ArcGIS Engine地理信息系统开发教程[M].北京:测绘出版社,2015.
2. 兰小机等,基于ArcObjects与C#.NET的GIS应用开发[M].北京:冶金工业出版社,2011.
---
# 资源
### 历届全国大学生GIS应用技能大赛试题及数据
链接：https://pan.baidu.com/s/1YcFV-wZuMJkF3e_9TNKs2Q#list/path=%2F
提取码：**1kxo**
