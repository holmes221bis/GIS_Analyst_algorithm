﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GIS应用系统
{
    public partial class Formlatlon : Form
    {
        public Formlatlon()
        {
            InitializeComponent();
        }
        struct locat
        {
            public double Long, lat, LongRad, latRad;
            public const double Ea = 6378137;
            public const double Eb = 6356725;
            public readonly double Ec;
            public readonly double Ed;




            /// JD  经度
            /// WD  纬度
            public locat(double JD, double WD)
            {
                Long = JD;
                lat = WD;
                LongRad = Long * Math.PI / 180; //计算出经弧度
                latRad = lat * Math.PI / 180;    //计算出纬弧度
                Ec = Eb + (Ea - Eb) * (90 - lat) / 90;
                Ed = Ec * Math.Cos(latRad);
            }
        }
        static string[] word(string inStr)
        {
            char[] wordchar = { ',', ' ', '\n' };
            string[] wordstr = inStr.Split(wordchar);
            return wordstr;
        }
        static void Calc(locat oneLct, locat twoLct)
        {
            double dx = (twoLct.LongRad - oneLct.LongRad) * oneLct.Ed;
            double dy = (twoLct.latRad - oneLct.latRad) * oneLct.Ec;
            double d = Math.Sqrt(dx * dx + dy * dy);

            MessageBox.Show("两点间的距离为"+d.ToString()); 

        }
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                Double onelctLong = Convert.ToDouble(textBox1.Text);
                Double onelctlat = Convert.ToDouble(textBox2.Text);

                Double twolctLong = Convert.ToDouble(textBox3.Text);
                Double twolctlat = Convert.ToDouble(textBox4.Text);

                locat onelct = new locat(onelctLong, onelctlat);
                locat twolct = new locat(twolctLong, twolctlat);

                //计算两坐标间的距离
                Calc(onelct, twolct);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n请按照格式输入正确的坐标！\n");   //如果输入格式不正确
            }

        }

    }
}
