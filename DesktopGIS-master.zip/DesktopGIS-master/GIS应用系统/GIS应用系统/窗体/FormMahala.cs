﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GIS应用系统
{
    public partial class FormMahala : Form
    {
        public FormMahala()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text!=""&&textBox2.Text!=""&&textBox3.Text!=""&&textBox4.Text!=""&&textBox5.Text!=""&&textBox6.Text!="")
            {
double average=(Convert.ToDouble(textBox1.Text)+Convert.ToDouble(textBox2.Text)+Convert.ToDouble(textBox3.Text))/3;
            double std=Math.Sqrt(((Convert.ToDouble(textBox1.Text)-average)*(Convert.ToDouble(textBox1.Text)-average)+(Convert.ToDouble(textBox2.Text)-average)*(Convert.ToDouble(textBox2.Text)-average)+(Convert.ToDouble(textBox3.Text)-average)*(Convert.ToDouble(textBox3.Text)-average))/3);
            double sum = Math.Sqrt((Convert.ToDouble(textBox1.Text) - Convert.ToDouble(textBox4.Text)) * (Convert.ToDouble(textBox1.Text) - Convert.ToDouble(textBox4.Text)) / std * std + (Convert.ToDouble(textBox2.Text) - Convert.ToDouble(textBox5.Text)) * (Convert.ToDouble(textBox2.Text) - Convert.ToDouble(textBox5.Text)) / std * std + (Convert.ToDouble(textBox3.Text) - Convert.ToDouble(textBox6.Text)) * (Convert.ToDouble(textBox3.Text) - Convert.ToDouble(textBox6.Text)) / std * std);
            MessageBox.Show("马氏距离为"+sum.ToString());
       
            }
            else
            {
                MessageBox.Show("请输入值");
            }
             }
    }
}
