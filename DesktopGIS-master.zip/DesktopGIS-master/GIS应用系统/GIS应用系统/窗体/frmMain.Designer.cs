﻿namespace GIS应用系统
{
    partial class frmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.axToolbarControl1 = new ESRI.ArcGIS.Controls.AxToolbarControl();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.axTOCControl1 = new ESRI.ArcGIS.Controls.AxTOCControl();
            this.eagleEyeMapControl = new ESRI.ArcGIS.Controls.AxMapControl();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.axLicenseControl1 = new ESRI.ArcGIS.Controls.AxLicenseControl();
            this.axMapControl1 = new ESRI.ArcGIS.Controls.AxMapControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.axPageLayoutControl1 = new ESRI.ArcGIS.Controls.AxPageLayoutControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.contextMenuAtributeTable = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuZoomToLayer = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuRemoveLayer = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuLayerSel = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuLayerUnSel = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuExportData = new System.Windows.Forms.ToolStripMenuItem();
            this.chkCustomize = new System.Windows.Forms.CheckBox();
            this.menuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuNewDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuOpenDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuSaveDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveAsDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.menuPrintMap = new System.Windows.Forms.ToolStripMenuItem();
            this.menuExportMap = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuExitProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStartEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSaveEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEndEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.menuSelectLayer = new System.Windows.Forms.ToolStripComboBox();
            this.menuAddLayerFeature = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMapView = new System.Windows.Forms.ToolStripMenuItem();
            this.menuZoomIn = new System.Windows.Forms.ToolStripMenuItem();
            this.menuZoomOut = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPan = new System.Windows.Forms.ToolStripMenuItem();
            this.menuFullExtent = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDataAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAddShapefile = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAddRaster = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAddXYData = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDataQuery = new System.Windows.Forms.ToolStripMenuItem();
            this.menuQueryByAttribute = new System.Windows.Forms.ToolStripMenuItem();
            this.menuQueryBySpatial = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStatistics = new System.Windows.Forms.ToolStripMenuItem();
            this.地图制图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.地图符号化ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSingleSymbol = new System.Windows.Forms.ToolStripMenuItem();
            this.menuUniqueValuesSymbol = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGraduatedColorSymbol = new System.Windows.Forms.ToolStripMenuItem();
            this.menuProportionalSymbols = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDotDensitySymbols = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMapMark = new System.Windows.Forms.ToolStripMenuItem();
            this.gP工具ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.缓冲区分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGPBuffer = new System.Windows.Forms.ToolStripMenuItem();
            this.menuIntersectTable = new System.Windows.Forms.ToolStripMenuItem();
            this.menuCustomTool = new System.Windows.Forms.ToolStripMenuItem();
            this.空间量测算法ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.空间分析算法ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.马氏距离量算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.经纬度距离量算ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.欧式距离ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.曼哈顿距离ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.棋盘距离ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.点到直线的距离ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.空间面积算法ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.面积量测ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.生成凸包ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.随机点ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eagleEyeMapControl)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axPageLayoutControl1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // axToolbarControl1
            // 
            this.axToolbarControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.axToolbarControl1.Location = new System.Drawing.Point(0, 25);
            this.axToolbarControl1.Margin = new System.Windows.Forms.Padding(2);
            this.axToolbarControl1.Name = "axToolbarControl1";
            this.axToolbarControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axToolbarControl1.OcxState")));
            this.axToolbarControl1.Size = new System.Drawing.Size(722, 28);
            this.axToolbarControl1.TabIndex = 0;
            this.axToolbarControl1.OnMouseDown += new ESRI.ArcGIS.Controls.IToolbarControlEvents_Ax_OnMouseDownEventHandler(this.axToolbarControl1_OnMouseDown);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 512);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 10, 0);
            this.statusStrip1.Size = new System.Drawing.Size(722, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 53);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(722, 459);
            this.splitContainer1.SplitterDistance = 261;
            this.splitContainer1.SplitterWidth = 3;
            this.splitContainer1.TabIndex = 4;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(2);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.axTOCControl1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.eagleEyeMapControl);
            this.splitContainer2.Size = new System.Drawing.Size(261, 459);
            this.splitContainer2.SplitterDistance = 227;
            this.splitContainer2.SplitterWidth = 3;
            this.splitContainer2.TabIndex = 0;
            // 
            // axTOCControl1
            // 
            this.axTOCControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axTOCControl1.Location = new System.Drawing.Point(0, 0);
            this.axTOCControl1.Margin = new System.Windows.Forms.Padding(2);
            this.axTOCControl1.Name = "axTOCControl1";
            this.axTOCControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axTOCControl1.OcxState")));
            this.axTOCControl1.Size = new System.Drawing.Size(261, 227);
            this.axTOCControl1.TabIndex = 0;
            this.axTOCControl1.OnMouseDown += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnMouseDownEventHandler(this.axTOCControl1_OnMouseDown);
            this.axTOCControl1.OnMouseUp += new ESRI.ArcGIS.Controls.ITOCControlEvents_Ax_OnMouseUpEventHandler(this.axTOCControl1_OnMouseUp);
            // 
            // eagleEyeMapControl
            // 
            this.eagleEyeMapControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.eagleEyeMapControl.Location = new System.Drawing.Point(0, 0);
            this.eagleEyeMapControl.Margin = new System.Windows.Forms.Padding(2);
            this.eagleEyeMapControl.Name = "eagleEyeMapControl";
            this.eagleEyeMapControl.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("eagleEyeMapControl.OcxState")));
            this.eagleEyeMapControl.Size = new System.Drawing.Size(261, 229);
            this.eagleEyeMapControl.TabIndex = 0;
            this.eagleEyeMapControl.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl2_OnMouseDown);
            this.eagleEyeMapControl.OnMouseMove += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseMoveEventHandler(this.axMapControl2_OnMouseMove);
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(458, 459);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.axLicenseControl1);
            this.tabPage1.Controls.Add(this.axMapControl1);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(450, 433);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "数据视图";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // axLicenseControl1
            // 
            this.axLicenseControl1.Enabled = true;
            this.axLicenseControl1.Location = new System.Drawing.Point(16, 6);
            this.axLicenseControl1.Margin = new System.Windows.Forms.Padding(2);
            this.axLicenseControl1.Name = "axLicenseControl1";
            this.axLicenseControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLicenseControl1.OcxState")));
            this.axLicenseControl1.Size = new System.Drawing.Size(32, 32);
            this.axLicenseControl1.TabIndex = 1;
            // 
            // axMapControl1
            // 
            this.axMapControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axMapControl1.Location = new System.Drawing.Point(2, 2);
            this.axMapControl1.Margin = new System.Windows.Forms.Padding(2);
            this.axMapControl1.Name = "axMapControl1";
            this.axMapControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axMapControl1.OcxState")));
            this.axMapControl1.Size = new System.Drawing.Size(446, 429);
            this.axMapControl1.TabIndex = 0;
            this.axMapControl1.OnMouseDown += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMouseDownEventHandler(this.axMapControl1_OnMouseDown);
            this.axMapControl1.OnAfterScreenDraw += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnAfterScreenDrawEventHandler(this.axMapControl1_OnAfterScreenDraw);
            this.axMapControl1.OnExtentUpdated += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnExtentUpdatedEventHandler(this.axMapControl1_OnExtentUpdated);
            this.axMapControl1.OnMapReplaced += new ESRI.ArcGIS.Controls.IMapControlEvents2_Ax_OnMapReplacedEventHandler(this.axMapControl1_OnMapReplaced);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.axPageLayoutControl1);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(450, 433);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "布局视图";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // axPageLayoutControl1
            // 
            this.axPageLayoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axPageLayoutControl1.Location = new System.Drawing.Point(2, 2);
            this.axPageLayoutControl1.Margin = new System.Windows.Forms.Padding(2);
            this.axPageLayoutControl1.Name = "axPageLayoutControl1";
            this.axPageLayoutControl1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axPageLayoutControl1.OcxState")));
            this.axPageLayoutControl1.Size = new System.Drawing.Size(446, 429);
            this.axPageLayoutControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.pictureBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(450, 433);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "画图控件";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(444, 427);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.DoubleClick += new System.EventHandler(this.pic_DoubleClick);
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_Click_1);
            // 
            // contextMenuStrip
            // 
            this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contextMenuAtributeTable,
            this.contextMenuZoomToLayer,
            this.contextMenuRemoveLayer,
            this.contextMenuLayerSel,
            this.contextMenuLayerUnSel,
            this.contextMenuExportData});
            this.contextMenuStrip.Name = "contextMenuStrip";
            this.contextMenuStrip.Size = new System.Drawing.Size(137, 136);
            // 
            // contextMenuAtributeTable
            // 
            this.contextMenuAtributeTable.Image = ((System.Drawing.Image)(resources.GetObject("contextMenuAtributeTable.Image")));
            this.contextMenuAtributeTable.Name = "contextMenuAtributeTable";
            this.contextMenuAtributeTable.Size = new System.Drawing.Size(136, 22);
            this.contextMenuAtributeTable.Text = "打开属性表";
            this.contextMenuAtributeTable.Click += new System.EventHandler(this.contextMenuAtributeTable_Click);
            // 
            // contextMenuZoomToLayer
            // 
            this.contextMenuZoomToLayer.Image = ((System.Drawing.Image)(resources.GetObject("contextMenuZoomToLayer.Image")));
            this.contextMenuZoomToLayer.Name = "contextMenuZoomToLayer";
            this.contextMenuZoomToLayer.Size = new System.Drawing.Size(136, 22);
            this.contextMenuZoomToLayer.Text = "缩放至图层";
            this.contextMenuZoomToLayer.Click += new System.EventHandler(this.contextMenuZoomToLayer_Click);
            // 
            // contextMenuRemoveLayer
            // 
            this.contextMenuRemoveLayer.Image = ((System.Drawing.Image)(resources.GetObject("contextMenuRemoveLayer.Image")));
            this.contextMenuRemoveLayer.Name = "contextMenuRemoveLayer";
            this.contextMenuRemoveLayer.Size = new System.Drawing.Size(136, 22);
            this.contextMenuRemoveLayer.Text = "移除图层";
            this.contextMenuRemoveLayer.Click += new System.EventHandler(this.contextMenuRemoveLayer_Click);
            // 
            // contextMenuLayerSel
            // 
            this.contextMenuLayerSel.Name = "contextMenuLayerSel";
            this.contextMenuLayerSel.Size = new System.Drawing.Size(136, 22);
            this.contextMenuLayerSel.Text = "图层可选";
            this.contextMenuLayerSel.Click += new System.EventHandler(this.contextMenuLayerSel_Click);
            // 
            // contextMenuLayerUnSel
            // 
            this.contextMenuLayerUnSel.Name = "contextMenuLayerUnSel";
            this.contextMenuLayerUnSel.Size = new System.Drawing.Size(136, 22);
            this.contextMenuLayerUnSel.Text = "图层不可选";
            this.contextMenuLayerUnSel.Click += new System.EventHandler(this.contextMenuLayerUnSel_Click);
            // 
            // contextMenuExportData
            // 
            this.contextMenuExportData.Image = ((System.Drawing.Image)(resources.GetObject("contextMenuExportData.Image")));
            this.contextMenuExportData.Name = "contextMenuExportData";
            this.contextMenuExportData.Size = new System.Drawing.Size(136, 22);
            this.contextMenuExportData.Text = "导出数据";
            this.contextMenuExportData.Click += new System.EventHandler(this.contextMenuExportData_Click);
            // 
            // chkCustomize
            // 
            this.chkCustomize.AutoSize = true;
            this.chkCustomize.BackColor = System.Drawing.Color.MistyRose;
            this.chkCustomize.Location = new System.Drawing.Point(596, 30);
            this.chkCustomize.Margin = new System.Windows.Forms.Padding(2);
            this.chkCustomize.Name = "chkCustomize";
            this.chkCustomize.Size = new System.Drawing.Size(84, 16);
            this.chkCustomize.TabIndex = 5;
            this.chkCustomize.Text = "定制工具条";
            this.chkCustomize.UseVisualStyleBackColor = false;
            this.chkCustomize.CheckedChanged += new System.EventHandler(this.chkCustomize_CheckedChanged);
            // 
            // menuFile
            // 
            this.menuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuNewDoc,
            this.menuOpenDoc,
            this.toolStripSeparator2,
            this.menuSaveDoc,
            this.menuSaveAsDoc,
            this.toolStripSeparator3,
            this.menuPrintMap,
            this.menuExportMap,
            this.toolStripSeparator1,
            this.menuExitProgram});
            this.menuFile.Name = "menuFile";
            this.menuFile.Size = new System.Drawing.Size(44, 21);
            this.menuFile.Text = "文件";
            // 
            // menuNewDoc
            // 
            this.menuNewDoc.Image = ((System.Drawing.Image)(resources.GetObject("menuNewDoc.Image")));
            this.menuNewDoc.Name = "menuNewDoc";
            this.menuNewDoc.Size = new System.Drawing.Size(124, 22);
            this.menuNewDoc.Text = "新建";
            this.menuNewDoc.Click += new System.EventHandler(this.menuNewDoc_Click);
            // 
            // menuOpenDoc
            // 
            this.menuOpenDoc.Image = ((System.Drawing.Image)(resources.GetObject("menuOpenDoc.Image")));
            this.menuOpenDoc.Name = "menuOpenDoc";
            this.menuOpenDoc.Size = new System.Drawing.Size(124, 22);
            this.menuOpenDoc.Text = "打开";
            this.menuOpenDoc.Click += new System.EventHandler(this.menuOpenDoc_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(121, 6);
            // 
            // menuSaveDoc
            // 
            this.menuSaveDoc.Image = ((System.Drawing.Image)(resources.GetObject("menuSaveDoc.Image")));
            this.menuSaveDoc.Name = "menuSaveDoc";
            this.menuSaveDoc.Size = new System.Drawing.Size(124, 22);
            this.menuSaveDoc.Text = "保存";
            this.menuSaveDoc.Click += new System.EventHandler(this.menuSaveDoc_Click);
            // 
            // menuSaveAsDoc
            // 
            this.menuSaveAsDoc.Image = ((System.Drawing.Image)(resources.GetObject("menuSaveAsDoc.Image")));
            this.menuSaveAsDoc.Name = "menuSaveAsDoc";
            this.menuSaveAsDoc.Size = new System.Drawing.Size(124, 22);
            this.menuSaveAsDoc.Text = "另存为";
            this.menuSaveAsDoc.Click += new System.EventHandler(this.menuSaveAsDoc_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(121, 6);
            // 
            // menuPrintMap
            // 
            this.menuPrintMap.Image = ((System.Drawing.Image)(resources.GetObject("menuPrintMap.Image")));
            this.menuPrintMap.Name = "menuPrintMap";
            this.menuPrintMap.Size = new System.Drawing.Size(124, 22);
            this.menuPrintMap.Text = "打印";
            this.menuPrintMap.Click += new System.EventHandler(this.menuPrintMap_Click);
            // 
            // menuExportMap
            // 
            this.menuExportMap.Name = "menuExportMap";
            this.menuExportMap.Size = new System.Drawing.Size(124, 22);
            this.menuExportMap.Text = "导出地图";
            this.menuExportMap.Click += new System.EventHandler(this.menuExportMap_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(121, 6);
            // 
            // menuExitProgram
            // 
            this.menuExitProgram.Name = "menuExitProgram";
            this.menuExitProgram.Size = new System.Drawing.Size(124, 22);
            this.menuExitProgram.Text = "退出";
            this.menuExitProgram.Click += new System.EventHandler(this.menuExitProgram_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuStartEdit,
            this.menuSaveEdit,
            this.menuEndEdit,
            this.toolStripSeparator4,
            this.menuSelectLayer,
            this.menuAddLayerFeature});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(44, 21);
            this.toolStripMenuItem1.Text = "编辑";
            // 
            // menuStartEdit
            // 
            this.menuStartEdit.Name = "menuStartEdit";
            this.menuStartEdit.Size = new System.Drawing.Size(181, 22);
            this.menuStartEdit.Text = "开始编辑";
            this.menuStartEdit.Click += new System.EventHandler(this.menuStartEdit_Click);
            // 
            // menuSaveEdit
            // 
            this.menuSaveEdit.Name = "menuSaveEdit";
            this.menuSaveEdit.Size = new System.Drawing.Size(181, 22);
            this.menuSaveEdit.Text = "保存编辑";
            this.menuSaveEdit.Click += new System.EventHandler(this.menuSaveEdit_Click);
            // 
            // menuEndEdit
            // 
            this.menuEndEdit.Name = "menuEndEdit";
            this.menuEndEdit.Size = new System.Drawing.Size(181, 22);
            this.menuEndEdit.Text = "结束编辑";
            this.menuEndEdit.Click += new System.EventHandler(this.menuEndEdit_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(178, 6);
            // 
            // menuSelectLayer
            // 
            this.menuSelectLayer.Name = "menuSelectLayer";
            this.menuSelectLayer.Size = new System.Drawing.Size(121, 25);
            this.menuSelectLayer.Text = "图层选择";
            this.menuSelectLayer.SelectedIndexChanged += new System.EventHandler(this.menuSelectLayer_SelectedIndexChanged);
            // 
            // menuAddLayerFeature
            // 
            this.menuAddLayerFeature.Name = "menuAddLayerFeature";
            this.menuAddLayerFeature.Size = new System.Drawing.Size(181, 22);
            this.menuAddLayerFeature.Text = "添加要素";
            this.menuAddLayerFeature.Click += new System.EventHandler(this.menuAddLayerFeature_Click);
            // 
            // menuMapView
            // 
            this.menuMapView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuZoomIn,
            this.menuZoomOut,
            this.menuPan,
            this.menuFullExtent});
            this.menuMapView.Name = "menuMapView";
            this.menuMapView.Size = new System.Drawing.Size(68, 21);
            this.menuMapView.Text = "地图浏览";
            // 
            // menuZoomIn
            // 
            this.menuZoomIn.Image = ((System.Drawing.Image)(resources.GetObject("menuZoomIn.Image")));
            this.menuZoomIn.Name = "menuZoomIn";
            this.menuZoomIn.Size = new System.Drawing.Size(100, 22);
            this.menuZoomIn.Text = "放大";
            this.menuZoomIn.Click += new System.EventHandler(this.menuZoomIn_Click);
            // 
            // menuZoomOut
            // 
            this.menuZoomOut.Image = ((System.Drawing.Image)(resources.GetObject("menuZoomOut.Image")));
            this.menuZoomOut.Name = "menuZoomOut";
            this.menuZoomOut.Size = new System.Drawing.Size(100, 22);
            this.menuZoomOut.Text = "缩小";
            this.menuZoomOut.Click += new System.EventHandler(this.menuZoomOut_Click);
            // 
            // menuPan
            // 
            this.menuPan.Image = ((System.Drawing.Image)(resources.GetObject("menuPan.Image")));
            this.menuPan.Name = "menuPan";
            this.menuPan.Size = new System.Drawing.Size(100, 22);
            this.menuPan.Text = "漫游";
            this.menuPan.Click += new System.EventHandler(this.menuPan_Click);
            // 
            // menuFullExtent
            // 
            this.menuFullExtent.Image = ((System.Drawing.Image)(resources.GetObject("menuFullExtent.Image")));
            this.menuFullExtent.Name = "menuFullExtent";
            this.menuFullExtent.Size = new System.Drawing.Size(100, 22);
            this.menuFullExtent.Text = "全图";
            this.menuFullExtent.Click += new System.EventHandler(this.menuFullExtent_Click);
            // 
            // menuDataAdd
            // 
            this.menuDataAdd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuAddShapefile,
            this.menuAddRaster,
            this.menuAddXYData});
            this.menuDataAdd.Name = "menuDataAdd";
            this.menuDataAdd.Size = new System.Drawing.Size(68, 21);
            this.menuDataAdd.Text = "数据加载";
            // 
            // menuAddShapefile
            // 
            this.menuAddShapefile.Name = "menuAddShapefile";
            this.menuAddShapefile.Size = new System.Drawing.Size(148, 22);
            this.menuAddShapefile.Text = "添加矢量数据";
            this.menuAddShapefile.Click += new System.EventHandler(this.menuAddShapefile_Click);
            // 
            // menuAddRaster
            // 
            this.menuAddRaster.Name = "menuAddRaster";
            this.menuAddRaster.Size = new System.Drawing.Size(148, 22);
            this.menuAddRaster.Text = "添加栅格数据";
            this.menuAddRaster.Click += new System.EventHandler(this.menuAddRaster_Click);
            // 
            // menuAddXYData
            // 
            this.menuAddXYData.Name = "menuAddXYData";
            this.menuAddXYData.Size = new System.Drawing.Size(148, 22);
            this.menuAddXYData.Text = "添加XY数据";
            this.menuAddXYData.Click += new System.EventHandler(this.menuAddXYData_Click);
            // 
            // menuDataQuery
            // 
            this.menuDataQuery.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuQueryByAttribute,
            this.menuQueryBySpatial,
            this.menuStatistics});
            this.menuDataQuery.Name = "menuDataQuery";
            this.menuDataQuery.Size = new System.Drawing.Size(68, 21);
            this.menuDataQuery.Text = "数据查询";
            // 
            // menuQueryByAttribute
            // 
            this.menuQueryByAttribute.Name = "menuQueryByAttribute";
            this.menuQueryByAttribute.Size = new System.Drawing.Size(124, 22);
            this.menuQueryByAttribute.Text = "属性查询";
            this.menuQueryByAttribute.Click += new System.EventHandler(this.menuQueryByAttribute_Click);
            // 
            // menuQueryBySpatial
            // 
            this.menuQueryBySpatial.Name = "menuQueryBySpatial";
            this.menuQueryBySpatial.Size = new System.Drawing.Size(124, 22);
            this.menuQueryBySpatial.Text = "空间查询";
            this.menuQueryBySpatial.Click += new System.EventHandler(this.menuQueryBySpatial_Click);
            // 
            // menuStatistics
            // 
            this.menuStatistics.Name = "menuStatistics";
            this.menuStatistics.Size = new System.Drawing.Size(124, 22);
            this.menuStatistics.Text = "统计";
            this.menuStatistics.Click += new System.EventHandler(this.menuStatistics_Click);
            // 
            // 地图制图ToolStripMenuItem
            // 
            this.地图制图ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.地图符号化ToolStripMenuItem,
            this.menuMapMark});
            this.地图制图ToolStripMenuItem.Name = "地图制图ToolStripMenuItem";
            this.地图制图ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.地图制图ToolStripMenuItem.Text = "地图制图";
            // 
            // 地图符号化ToolStripMenuItem
            // 
            this.地图符号化ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuSingleSymbol,
            this.menuUniqueValuesSymbol,
            this.menuGraduatedColorSymbol,
            this.menuProportionalSymbols,
            this.menuDotDensitySymbols});
            this.地图符号化ToolStripMenuItem.Name = "地图符号化ToolStripMenuItem";
            this.地图符号化ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.地图符号化ToolStripMenuItem.Text = "地图符号化";
            // 
            // menuSingleSymbol
            // 
            this.menuSingleSymbol.Name = "menuSingleSymbol";
            this.menuSingleSymbol.Size = new System.Drawing.Size(160, 22);
            this.menuSingleSymbol.Text = "单一符号化";
            this.menuSingleSymbol.Click += new System.EventHandler(this.menuSingleSymbol_Click);
            // 
            // menuUniqueValuesSymbol
            // 
            this.menuUniqueValuesSymbol.Name = "menuUniqueValuesSymbol";
            this.menuUniqueValuesSymbol.Size = new System.Drawing.Size(160, 22);
            this.menuUniqueValuesSymbol.Text = "唯一值符号化";
            this.menuUniqueValuesSymbol.Click += new System.EventHandler(this.menuUniqueValuesSymbol_Click);
            // 
            // menuGraduatedColorSymbol
            // 
            this.menuGraduatedColorSymbol.Name = "menuGraduatedColorSymbol";
            this.menuGraduatedColorSymbol.Size = new System.Drawing.Size(160, 22);
            this.menuGraduatedColorSymbol.Text = "分级色彩符号化";
            this.menuGraduatedColorSymbol.Click += new System.EventHandler(this.menuGraduatedColorSymbol_Click);
            // 
            // menuProportionalSymbols
            // 
            this.menuProportionalSymbols.Name = "menuProportionalSymbols";
            this.menuProportionalSymbols.Size = new System.Drawing.Size(160, 22);
            this.menuProportionalSymbols.Text = "依比例符号化";
            this.menuProportionalSymbols.Click += new System.EventHandler(this.menuProportionalSymbols_Click);
            // 
            // menuDotDensitySymbols
            // 
            this.menuDotDensitySymbols.Name = "menuDotDensitySymbols";
            this.menuDotDensitySymbols.Size = new System.Drawing.Size(160, 22);
            this.menuDotDensitySymbols.Text = "点密度符号化";
            this.menuDotDensitySymbols.Click += new System.EventHandler(this.menuDotDensitySymbols_Click);
            // 
            // menuMapMark
            // 
            this.menuMapMark.Name = "menuMapMark";
            this.menuMapMark.Size = new System.Drawing.Size(136, 22);
            this.menuMapMark.Text = "地图标注";
            this.menuMapMark.Click += new System.EventHandler(this.menuMapMark_Click);
            // 
            // gP工具ToolStripMenuItem
            // 
            this.gP工具ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.缓冲区分析ToolStripMenuItem,
            this.menuCustomTool});
            this.gP工具ToolStripMenuItem.Name = "gP工具ToolStripMenuItem";
            this.gP工具ToolStripMenuItem.Size = new System.Drawing.Size(60, 21);
            this.gP工具ToolStripMenuItem.Text = "GP工具";
            // 
            // 缓冲区分析ToolStripMenuItem
            // 
            this.缓冲区分析ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuGPBuffer,
            this.menuIntersectTable});
            this.缓冲区分析ToolStripMenuItem.Name = "缓冲区分析ToolStripMenuItem";
            this.缓冲区分析ToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.缓冲区分析ToolStripMenuItem.Text = "系统工具";
            // 
            // menuGPBuffer
            // 
            this.menuGPBuffer.Name = "menuGPBuffer";
            this.menuGPBuffer.Size = new System.Drawing.Size(136, 22);
            this.menuGPBuffer.Text = "缓冲区分析";
            this.menuGPBuffer.Click += new System.EventHandler(this.menuGPBuffer_Click);
            // 
            // menuIntersectTable
            // 
            this.menuIntersectTable.Name = "menuIntersectTable";
            this.menuIntersectTable.Size = new System.Drawing.Size(136, 22);
            this.menuIntersectTable.Text = "交集制表";
            this.menuIntersectTable.Click += new System.EventHandler(this.menuIntersectTable_Click);
            // 
            // menuCustomTool
            // 
            this.menuCustomTool.Name = "menuCustomTool";
            this.menuCustomTool.Size = new System.Drawing.Size(136, 22);
            this.menuCustomTool.Text = "自定义工具";
            this.menuCustomTool.Click += new System.EventHandler(this.menuCustomTool_Click);
            // 
            // 空间量测算法ToolStripMenuItem
            // 
            this.空间量测算法ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.空间分析算法ToolStripMenuItem,
            this.空间面积算法ToolStripMenuItem});
            this.空间量测算法ToolStripMenuItem.Name = "空间量测算法ToolStripMenuItem";
            this.空间量测算法ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.空间量测算法ToolStripMenuItem.Text = "空间量测算法";
            // 
            // 空间分析算法ToolStripMenuItem
            // 
            this.空间分析算法ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.马氏距离量算ToolStripMenuItem,
            this.经纬度距离量算ToolStripMenuItem,
            this.欧式距离ToolStripMenuItem,
            this.曼哈顿距离ToolStripMenuItem,
            this.棋盘距离ToolStripMenuItem,
            this.点到直线的距离ToolStripMenuItem});
            this.空间分析算法ToolStripMenuItem.Name = "空间分析算法ToolStripMenuItem";
            this.空间分析算法ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.空间分析算法ToolStripMenuItem.Text = "空间距离算法";
            // 
            // 马氏距离量算ToolStripMenuItem
            // 
            this.马氏距离量算ToolStripMenuItem.Name = "马氏距离量算ToolStripMenuItem";
            this.马氏距离量算ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.马氏距离量算ToolStripMenuItem.Text = "马氏距离量算";
            this.马氏距离量算ToolStripMenuItem.Click += new System.EventHandler(this.马氏距离量算ToolStripMenuItem_Click);
            // 
            // 经纬度距离量算ToolStripMenuItem
            // 
            this.经纬度距离量算ToolStripMenuItem.Name = "经纬度距离量算ToolStripMenuItem";
            this.经纬度距离量算ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.经纬度距离量算ToolStripMenuItem.Text = "经纬度距离量算";
            this.经纬度距离量算ToolStripMenuItem.Click += new System.EventHandler(this.经纬度距离量算ToolStripMenuItem_Click);
            // 
            // 欧式距离ToolStripMenuItem
            // 
            this.欧式距离ToolStripMenuItem.Name = "欧式距离ToolStripMenuItem";
            this.欧式距离ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.欧式距离ToolStripMenuItem.Text = "欧式距离";
            this.欧式距离ToolStripMenuItem.Click += new System.EventHandler(this.欧式距离ToolStripMenuItem_Click);
            // 
            // 曼哈顿距离ToolStripMenuItem
            // 
            this.曼哈顿距离ToolStripMenuItem.Name = "曼哈顿距离ToolStripMenuItem";
            this.曼哈顿距离ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.曼哈顿距离ToolStripMenuItem.Text = "曼哈顿距离";
            this.曼哈顿距离ToolStripMenuItem.Click += new System.EventHandler(this.曼哈顿距离ToolStripMenuItem_Click);
            // 
            // 棋盘距离ToolStripMenuItem
            // 
            this.棋盘距离ToolStripMenuItem.Name = "棋盘距离ToolStripMenuItem";
            this.棋盘距离ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.棋盘距离ToolStripMenuItem.Text = "棋盘距离";
            this.棋盘距离ToolStripMenuItem.Click += new System.EventHandler(this.棋盘距离ToolStripMenuItem_Click);
            // 
            // 点到直线的距离ToolStripMenuItem
            // 
            this.点到直线的距离ToolStripMenuItem.Name = "点到直线的距离ToolStripMenuItem";
            this.点到直线的距离ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.点到直线的距离ToolStripMenuItem.Text = "点到直线的距离";
            this.点到直线的距离ToolStripMenuItem.Click += new System.EventHandler(this.点到直线的距离ToolStripMenuItem_Click);
            // 
            // 空间面积算法ToolStripMenuItem
            // 
            this.空间面积算法ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.面积量测ToolStripMenuItem,
            this.生成凸包ToolStripMenuItem,
            this.随机点ToolStripMenuItem});
            this.空间面积算法ToolStripMenuItem.Name = "空间面积算法ToolStripMenuItem";
            this.空间面积算法ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.空间面积算法ToolStripMenuItem.Text = "空间面积算法";
            // 
            // 面积量测ToolStripMenuItem
            // 
            this.面积量测ToolStripMenuItem.Name = "面积量测ToolStripMenuItem";
            this.面积量测ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.面积量测ToolStripMenuItem.Text = "平面多边形面积量测";
            this.面积量测ToolStripMenuItem.Click += new System.EventHandler(this.面积量测ToolStripMenuItem_Click);
            // 
            // 生成凸包ToolStripMenuItem
            // 
            this.生成凸包ToolStripMenuItem.Name = "生成凸包ToolStripMenuItem";
            this.生成凸包ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.生成凸包ToolStripMenuItem.Text = "生成凸包";
            this.生成凸包ToolStripMenuItem.Click += new System.EventHandler(this.生成凸包ToolStripMenuItem_Click);
            // 
            // 随机点ToolStripMenuItem
            // 
            this.随机点ToolStripMenuItem.Name = "随机点ToolStripMenuItem";
            this.随机点ToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.随机点ToolStripMenuItem.Text = "随机点";
            this.随机点ToolStripMenuItem.Click += new System.EventHandler(this.随机点ToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuFile,
            this.toolStripMenuItem1,
            this.menuMapView,
            this.menuDataAdd,
            this.menuDataQuery,
            this.地图制图ToolStripMenuItem,
            this.gP工具ToolStripMenuItem,
            this.空间量测算法ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(722, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // frmMain
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(722, 534);
            this.Controls.Add(this.chkCustomize);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.axToolbarControl1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmMain";
            this.Text = "GIS应用系统";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axToolbarControl1)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axTOCControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eagleEyeMapControl)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axLicenseControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axMapControl1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.axPageLayoutControl1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ESRI.ArcGIS.Controls.AxToolbarControl axToolbarControl1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private ESRI.ArcGIS.Controls.AxTOCControl axTOCControl1;
        private ESRI.ArcGIS.Controls.AxMapControl eagleEyeMapControl;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private ESRI.ArcGIS.Controls.AxMapControl axMapControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private ESRI.ArcGIS.Controls.AxPageLayoutControl axPageLayoutControl1;
        private ESRI.ArcGIS.Controls.AxLicenseControl axLicenseControl1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem contextMenuAtributeTable;
        private System.Windows.Forms.ToolStripMenuItem contextMenuZoomToLayer;
        private System.Windows.Forms.ToolStripMenuItem contextMenuRemoveLayer;
        private System.Windows.Forms.ToolStripMenuItem contextMenuLayerSel;
        private System.Windows.Forms.ToolStripMenuItem contextMenuLayerUnSel;
        private System.Windows.Forms.ToolStripMenuItem contextMenuExportData;
        private System.Windows.Forms.CheckBox chkCustomize;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem menuFile;
        private System.Windows.Forms.ToolStripMenuItem menuNewDoc;
        private System.Windows.Forms.ToolStripMenuItem menuOpenDoc;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem menuSaveDoc;
        private System.Windows.Forms.ToolStripMenuItem menuSaveAsDoc;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem menuPrintMap;
        private System.Windows.Forms.ToolStripMenuItem menuExportMap;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuExitProgram;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem menuStartEdit;
        private System.Windows.Forms.ToolStripMenuItem menuSaveEdit;
        private System.Windows.Forms.ToolStripMenuItem menuEndEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripComboBox menuSelectLayer;
        private System.Windows.Forms.ToolStripMenuItem menuAddLayerFeature;
        private System.Windows.Forms.ToolStripMenuItem menuMapView;
        private System.Windows.Forms.ToolStripMenuItem menuZoomIn;
        private System.Windows.Forms.ToolStripMenuItem menuZoomOut;
        private System.Windows.Forms.ToolStripMenuItem menuPan;
        private System.Windows.Forms.ToolStripMenuItem menuFullExtent;
        private System.Windows.Forms.ToolStripMenuItem menuDataAdd;
        private System.Windows.Forms.ToolStripMenuItem menuAddShapefile;
        private System.Windows.Forms.ToolStripMenuItem menuAddRaster;
        private System.Windows.Forms.ToolStripMenuItem menuAddXYData;
        private System.Windows.Forms.ToolStripMenuItem menuDataQuery;
        private System.Windows.Forms.ToolStripMenuItem menuQueryByAttribute;
        private System.Windows.Forms.ToolStripMenuItem menuQueryBySpatial;
        private System.Windows.Forms.ToolStripMenuItem menuStatistics;
        private System.Windows.Forms.ToolStripMenuItem 地图制图ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 地图符号化ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuSingleSymbol;
        private System.Windows.Forms.ToolStripMenuItem menuUniqueValuesSymbol;
        private System.Windows.Forms.ToolStripMenuItem menuGraduatedColorSymbol;
        private System.Windows.Forms.ToolStripMenuItem menuProportionalSymbols;
        private System.Windows.Forms.ToolStripMenuItem menuDotDensitySymbols;
        private System.Windows.Forms.ToolStripMenuItem menuMapMark;
        private System.Windows.Forms.ToolStripMenuItem gP工具ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 缓冲区分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuGPBuffer;
        private System.Windows.Forms.ToolStripMenuItem menuIntersectTable;
        private System.Windows.Forms.ToolStripMenuItem menuCustomTool;
        private System.Windows.Forms.ToolStripMenuItem 空间量测算法ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 空间分析算法ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 马氏距离量算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 经纬度距离量算ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 空间面积算法ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 面积量测ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 欧式距离ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 曼哈顿距离ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 棋盘距离ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 生成凸包ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 随机点ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 点到直线的距离ToolStripMenuItem;
    }
}

