﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GIS应用系统
{
    public partial class FormAddZInfo : Form
    {
        frmMain F1;
        public FormAddZInfo(frmMain F)
        {
            F1 = F;
            InitializeComponent();
        }
        public void GetZvalue(frmMain F1)
        {
            F1.z = Convert.ToDouble(textBox1.Text);
        }
        private void button1_Click(object sender, EventArgs e)
        {

            GetZvalue(F1);
            this.Close();
        }
    }
}
